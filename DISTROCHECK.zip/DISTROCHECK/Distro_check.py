from flask import Flask, jsonify, render_template_string, request
import requests
import base64
import re
import pandas as pd
from collections import Counter
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

app = Flask(__name__)
GITHUB_TOKEN = "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"  # Replace with your actual token

def sanitize_url(url):
    if pd.isna(url):
        return ""
    url_str = str(url).strip()
    if url_str.lower() in {"", "nan", "none"}:
        return ""
    return url_str

def safe_str(value):
    if pd.isna(value):
        return ""
    try:
        return str(value)
    except Exception:
        return ""

def convert_to_raw_url(url):
    return url.replace("github.com", "raw.githubusercontent.com").replace("/blob/", "/")

def extract_numeric_versions(distro_str):
    numbers = re.findall(r'\d+\.\d+', distro_str)
    return {float(n) for n in numbers}

def normalize_distro(distro):
    distro = distro.lower().replace(" ", "")
    distro = re.sub(r'sles\s*(\d+)\s*sp(\d+)', r'sles-\1.\2', distro)
    distro = re.sub(r'sles\s*\((\d+)\s*sp(\d+)\)', r'sles-\1.\2', distro)
    distro = re.sub(r'sl(\d+\.\d+)', r'sles-\1', distro)
    distro = re.sub(r'rhel\s*\(([\d.,\s]+)\)', r'rhel-\1', distro)
    distro = re.sub(r'ubuntu\s*\(([\d.,\s]+)\)', r'ubuntu-\1', distro)
    return distro

def extract_distros_from_build_script(content):
    distro_versions = {"ubuntu": set(), "rhel": set(), "sles": set()}
    matches = re.findall(r'"(rhel|sles|ubuntu)-(\d+\.\d+)"', content)
    for name, version in matches:
        distro_versions[name].add(float(version))
    return distro_versions

def extract_distro_versions(text):
    distro_versions = {"rhel": set(), "sles": set(), "ubuntu": set()}

    # Extract RHEL versions, ensuring no software versions are picked
    rhel_matches = re.findall(r"RHEL\s*\(?([\d\.,\s]+)\)?", text, re.IGNORECASE)
    for match in rhel_matches:
        rhel_versions = re.findall(r"\b\d+\.\d+\b", match)  # Extract numbers correctly
        distro_versions["rhel"].update({float(v) for v in rhel_versions})

    # Extract Ubuntu versions, ignoring software versions
    ubuntu_matches = re.findall(r"Ubuntu\s*\(?([\d\.,\s]+)\)?", text, re.IGNORECASE)
    for match in ubuntu_matches:
        ubuntu_versions = re.findall(r"\b\d+\.\d+\b", match)
        distro_versions["ubuntu"].update({float(v) for v in ubuntu_versions})

    # Extract SLES versions
    sles_match = re.search(r"SLES\s*\(?([\d\sSP,]+)\)?", text, re.IGNORECASE)
    if sles_match:
        sles_versions = re.findall(r'(\d+)\s*SP(\d+)', sles_match.group(1))
        if sles_versions:
            extracted_sles = {float(f"{major}.{minor}") for major, minor in sles_versions}
            distro_versions["sles"].update(extracted_sles)
            
    return distro_versions


def extract_distros_from_jenkinsfile2(content):
    distro_versions = {"ubuntu": set(), "rhel": set(), "sles": set()}
    matches = re.findall(r"'([^']+)'", content)
    for entry in matches:
        entry = entry.strip()
        if entry.startswith("ub"):
            distro_versions["ubuntu"].update(extract_numeric_versions(entry))
        elif entry.startswith("rh"):
            distro_versions["rhel"].update(extract_numeric_versions(entry))
        elif entry.startswith("sl"):
            distro_versions["sles"].update(extract_numeric_versions(entry))
            #sles_versions = re.findall(r'sles[-_]?(?P<major>\d+)[-_]?sp(?P<minor>\d+)', entry, re.IGNORECASE)
            #distro_versions["sles"].update({float(f"{major}.{minor}") for major, minor in sles_versions})

    return distro_versions

def extract_distros_from_jenkinsfile(content):
    matches = re.findall(r'nodeName = \[(.*?)\]', content)
    return " ".join(matches)  # Returning string for further processing

def compare_distros(bi_distros, jenkins_distros, build_script_distros,
                    build_script_available, bi_available, jenkins_available):
    mismatches = []

    for distro in ["rhel", "ubuntu", "sles"]:
        bi_set = bi_distros.get(distro, set())
        jenkins_set = jenkins_distros.get(distro, set())
        build_script_set = build_script_distros.get(distro, set())

        # BI vs Jenkins
        if bi_available and jenkins_available:
            missing_in_jenkins = bi_set - jenkins_set
            missing_in_bi = jenkins_set - bi_set
            if missing_in_jenkins:
                mismatches.append(f"🔘 BI mentions {distro.upper()} {missing_in_jenkins} but it's missing in Jenkinsfile.")
            if missing_in_bi:
                mismatches.append(f"🔘 Jenkinsfile mentions {distro.upper()} {missing_in_bi} but it's missing in BI page.")

        # BI vs Build Script
        if bi_available and build_script_available:
            missing_in_build_script = bi_set - build_script_set
            extra_in_build_script = build_script_set - bi_set
            if missing_in_build_script:
                mismatches.append(f"🔘 BI mentions {distro.upper()} {missing_in_build_script} but it's missing in Build Script.")
            if extra_in_build_script:
                mismatches.append(f"🔘 Build Script mentions {distro.upper()} {extra_in_build_script} but it's missing in BI page.")

        # Jenkins vs Build Script — this is NEW
        if jenkins_available and build_script_available:
            missing_in_build_script = jenkins_set - build_script_set
            extra_in_build_script = build_script_set - jenkins_set
            if missing_in_build_script:
                mismatches.append(f"🔘 Jenkinsfile mentions {distro.upper()} {missing_in_build_script} but it's missing in Build Script.")
            if extra_in_build_script:
                mismatches.append(f"🔘 Build Script mentions {distro.upper()} {extra_in_build_script} but it's missing in Jenkinsfile.")

    return "<br>".join(mismatches) if mismatches else "All match"

def fetch_url(url):
    try:
        response = requests.get(url, verify=False)  # SSL verification disabled
        response.raise_for_status()
        return response.text
    except requests.exceptions.SSLError as ssl_err:
        #print(f"SSL error when accessing {url}: {ssl_err}")
        return ""
    except requests.exceptions.RequestException as req_err:
        #print(f"Error fetching {url}: {req_err}")
        return ""

def fetch_jenkinsfile_from_branch(repo_url, branch):
    owner, repo = repo_url.split('/')[-2:]
    api_url = f"https://api.github.com/repos/{owner}/{repo}/contents/Jenkinsfile?ref={branch}"
    
    headers = {"Authorization": f"token {GITHUB_TOKEN}"}
    
    try:
        response = requests.get(api_url, headers=headers, verify=False)
        response.raise_for_status()
        content = response.json().get("content", "")
        return base64.b64decode(content).decode("utf-8")
    except requests.RequestException:
        return ""

def clean_package_name(package_name):
    return re.sub(r"\s+\d+(\.\d+)?[.]?[xX]?", "", package_name).strip()

def extract_package_version(text, package_name):
    normalized_package_name = clean_package_name(package_name)
    patterns = [
        rf"{re.escape(normalized_package_name)}[^\d]*?(version)?\s*([vV]?\d+\.\d+\.\d+)\b",  # e.g., "PackageName version 1.2.3"
        rf"{re.escape(normalized_package_name)}.*?\(.*?([vV]?\d+\.\d+\.\d+)\)", # e.g., "PackageName (v1.2.3)"
        rf"{re.escape(normalized_package_name)}.*?version\s*[:\s]*([vV]?(\d+\.\d+))",  # e.g., "PostgreSQL version 17.4"
        rf"{re.escape(normalized_package_name)}.*?([vV]?(\d+\.\d+))",  # e.g., "PostgreSQL v17.4"
        rf"The instructions provided below specify the steps to build {re.escape(normalized_package_name)} version\s*(\d+\.\d+)", # Handles PostgreSQL 17.x case
    ]

    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            try:
                # If version is in group 2, return it, otherwise return group 1
                version = match.group(2) if len(match.groups()) > 1 and match.group(2) else match.group(1)
                return version.lstrip('vV')
            except IndexError:
                return "Unknown"
    return "Unknown"

def extract_package_version_from_build_script(content):
    match = re.search(r'PACKAGE_VERSION\s*=\s*["\']v?([\d\.]+)["\']', content, re.IGNORECASE)
    return match.group(1) if match else "Unknown"

@app.route('/')
def index():
    return render_template_string("""
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Distro Comparison</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: Arial, sans-serif; background-color: #f8f9fa; margin: 20px; }
        .container { max-width: 90%; }
        h2 { text-align: center; color: #4a4ae6; margin-bottom: 8px; }
        .table-container { border-radius: 10px; box-shadow: 0px 4px 10px rgba(0,0,0,0.1); overflow: hidden; }
        .table thead tr th { background-color: #4a4ae6 !important; color: white !important; }
        .table tbody tr:nth-child(even) { background-color: #f9f9ff; }
        .table tbody tr:hover { background-color: #e8e8ff; }
        .status-green { background-color: #d4edda !important; color: #155724 !important; font-weight: bold; }
        .status-red { background-color: #f8d7da !important; color: #721c24 !important; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h2>Distro Consistency Check</h2>
        <div class="text-end mb-2">
            <div class="form-check form-switch d-inline-flex align-items-center">
                <input class="form-check-input" type="checkbox" id="toggleMismatch" onchange="filterTable()" style="transform: scale(1.2);">
                <label class="form-check-label ms-2" for="toggleMismatch" style="font-size: 1rem; color: #4a4ae6;">Show Mismatches Only</label>
            </div>
        </div>

        <div class="table-container">
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Package Name</th>
                            <th>Build Instructions</th>
                            <th>Jenkinsfile</th>
                            <th>Build Script</th>
                            <th>Comments</th>
                        </tr>
                    </thead>
                    <tbody id="table-body"></tbody>
                </table>
            </div>
        </div>

        <div class="d-flex justify-content-center mt-3">
    <div id="pagination" class="btn-group"></div>
</div>

    </div>

    <script>
    let currentPage = 1;
    const perPage = 15;

    async function fetchData(page = 1) {
        const response = await fetch(`/data?page=${page}&per_page=${perPage}`);
        const result = await response.json();
        
        console.log("Fetched data:", result);  
        
        const data = result.data;
        const totalPages = result.total_pages;
        currentPage = result.current_page;

        const tableBody = document.getElementById('table-body');
        tableBody.innerHTML = '';

        data.forEach(item => {
            let jenkinsLinks = "N/A";
            if (item.jenkinsfile_links && Object.keys(item.jenkinsfile_links).length > 0) {
                jenkinsLinks = Object.entries(item.jenkinsfile_links)
                    .map(([branch, url]) => `<div><a href="${url}" class="btn btn-primary btn-sm mb-1" target="_blank">${branch}</a></div>`)
                    .join('');
            }

            const commentClass = item.comments.toLowerCase().includes("all match") ? "status-green" : "status-red";
            const row = document.createElement('tr');
            row.classList.add(commentClass === "status-red" ? "mismatch" : "match");
            row.innerHTML = `
                <td>${item.package_name}</td>
                <td>${
                    item.bi_link.url
                        ? `<a href="${item.bi_link.url}" class="btn btn-primary btn-sm" target="_blank">v${item.bi_link.version}</a>`
                        : "N/A"
                }</td>

                <td>${jenkinsLinks}</td>
                <td>${item.build_script_link.url ? `<a href="${item.build_script_link.url}" class="btn btn-primary btn-sm" target="_blank">v${item.build_script_link.version}</a>` : "N/A"}</td>
                <td class="${commentClass}">${item.comments}</td>
            `;
            tableBody.appendChild(row);
        });

        renderPagination(totalPages);
    }

    function renderPagination(totalPages) {
        const container = document.getElementById('pagination');
        container.innerHTML = '';

        const prev = document.createElement('button');
        prev.innerText = 'Previous';
        prev.className = 'btn btn-outline-primary btn-sm me-2';
        prev.disabled = currentPage === 1;
        prev.onclick = () => fetchData(currentPage - 1);
        container.appendChild(prev);

        for (let i = 1; i <= totalPages; i++) {
            const btn = document.createElement('button');
            btn.innerText = i;
            btn.className = `btn btn-sm me-1 ${i === currentPage ? 'btn-primary' : 'btn-outline-primary'}`;
            btn.onclick = () => fetchData(i);
            container.appendChild(btn);
        }

        const next = document.createElement('button');
        next.innerText = 'Next';
        next.className = 'btn btn-outline-primary btn-sm ms-2';
        next.disabled = currentPage === totalPages;
        next.onclick = () => fetchData(currentPage + 1);
        container.appendChild(next);
    }

    function filterTable() {
        const showMismatchesOnly = document.getElementById('toggleMismatch').checked;
        document.querySelectorAll('#table-body tr').forEach(row => {
            row.style.display = showMismatchesOnly && !row.classList.contains('mismatch') ? 'none' : '';
        });
    }

    window.onload = () => fetchData();
</script>

</body>
</html>
""")


@app.route('/data')
def get_data():
    # Pagination parameters
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 15))

    # Read data from Excel
    df = pd.read_excel("data.xlsx")  
    total_packages = len(df)
    total_pages = (total_packages + per_page - 1) // per_page

    # Paginate
    start = (page - 1) * per_page
    end = start + per_page
    df_page = df.iloc[start:end]

    data = []

    for _, row in df_page.iterrows():
        package_name = row["package_name"]
        bi_url = sanitize_url(row["bi_url"])
        repo_url = sanitize_url(row["repo_url"])
        build_script_url = sanitize_url(row["build_script_url"])

        raw_build_script_url = convert_to_raw_url(build_script_url) if build_script_url else ""
        branches = ["rhel", "sles", "ubuntu"]

        bi_content = fetch_url(bi_url)
        bi_distros = extract_distro_versions(bi_content)
        print(f"BI page Detected Distros for {package_name}: {bi_distros}")  # Debugging Output

        bi_version = extract_package_version(bi_content, package_name) or "N/A"

        jenkins_distros = {"ubuntu": set(), "rhel": set(), "sles": set()}
        jenkinsfile_links = {}
 
        if repo_url:
            for branch in branches:
                jenkins_content = fetch_jenkinsfile_from_branch(repo_url, branch)
                if jenkins_content.strip():
                    extracted_content = extract_distros_from_jenkinsfile(jenkins_content)
                    branch_distros = extract_distros_from_jenkinsfile2(extracted_content)
                    if any(branch_distros.values()):
                        for key in jenkins_distros:
                            jenkins_distros[key].update(branch_distros[key])
                        jenkinsfile_links[branch] = f"{repo_url}/blob/{branch}/Jenkinsfile"

        print(f"Jenkinsfile Detected Distros for {package_name}: {jenkins_distros}")

        build_script_content = fetch_url(raw_build_script_url)
        build_script_distros = extract_distros_from_build_script(build_script_content)
        build_script_version = extract_package_version_from_build_script(build_script_content)
        print(f"Build Script Detected Distros for {package_name}: {build_script_distros}")
        print(f"\n")
        
        comments = compare_distros(
            bi_distros,
            jenkins_distros,
            build_script_distros,
            bool(build_script_url),
            bool(bi_url),
            bool(jenkinsfile_links)  # Only if we actually found at least one Jenkinsfile
        )


        data.append({
            "package_name": safe_str(package_name),
            "jenkinsfile_links": {
                branch: safe_str(url) for branch, url in jenkinsfile_links.items()
            } if jenkinsfile_links else {},
            "bi_link": {
                "url": safe_str(bi_url),
                "version": safe_str(bi_version)
            },
            "build_script_link": {
                "url": safe_str(build_script_url),
                "version": safe_str(build_script_version)
            },
            "comments": safe_str(comments)
        })


    return jsonify({
        "data": data,
        "total_pages": total_pages,
        "current_page": page
    })

if __name__ == '__main__':
    app.run(debug=True)